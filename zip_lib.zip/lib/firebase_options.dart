// File generated manually for multi-platform support
// ignore_for_file: type=lint

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
/// Works on Android, iOS, and Web.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // Android config
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBIusSIADL5Sx1cgIhRiVJhlMzKMj1xcWY',
    appId: '1:560318789684:android:69d2687a776814c8c13261',
    messagingSenderId: '560318789684',
    projectId: 'pillmate-257a9',
    storageBucket: 'pillmate-257a9.firebasestorage.app',
  );

  // iOS config
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCy0_sxM_DoTyQu_NRLUmaE_XOof0bHvg8',
    appId: '1:560318789684:ios:7ae0330619cdfdbcc13261',
    messagingSenderId: '560318789684',
    projectId: 'pillmate-257a9',
    storageBucket: 'pillmate-257a9.firebasestorage.app',
    iosBundleId: 'com.example.pillmateCollege',
  );

  // Web config
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBIusSIADL5Sx1cgIhRiVJhlMzKMj1xcWY', // replace with your Web API key if different
    appId: '1:560318789684:web:69d2687a776814c8c13261',  // Web appId from Firebase console
    messagingSenderId: '560318789684',
    projectId: 'pillmate-257a9',
    storageBucket: 'pillmate-257a9.appspot.com',
  );
}