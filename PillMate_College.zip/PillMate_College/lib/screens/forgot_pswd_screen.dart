import 'package:flutter/material.dart';
import 'package:pillmate_college/screens/opt_screen.dart';
import '../widget/reusable_widgets.dart';
//import 'otp_screen.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenWrapper(
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        children: [
          const SizedBox(height: 80),
          Image.asset('assets/images/img_9.png', height: 200),
          const SizedBox(height: 30),
          const Text("Forgot Password?", textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text("Enter your email to receive a password reset link", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 40),
          const Text("Enter Email", style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(decoration: InputDecoration(hintText: "Email", filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
          const SizedBox(height: 40),
          PrimaryButton(text: "Send code", onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const OtpScreen()))),
        ],
      ),
    );
  }
}