import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class SettingProfileScreen extends StatefulWidget {
  const SettingProfileScreen({super.key});

  @override
  State<SettingProfileScreen> createState() => _SettingProfileScreenState();
}

class _SettingProfileScreenState extends State<SettingProfileScreen> {
  TextEditingController nameController = TextEditingController();

  String selectedGender = "Select";
  String selectedDate = "Select";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F7FF),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        children: [
          const SizedBox(height: 80),

          const Center(
            child: CircleAvatar(
              radius: 60,
              backgroundColor: Color(0xFF4C8CFF),
              child: Icon(Icons.person, size: 80, color: Colors.white),
            ),
          ),

          const SizedBox(height: 30),

          const Text(
            "Complete your profile",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 40),

          const Text(
            "Name",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),

          TextField(
            controller: nameController,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              hintText: "Enter your name",
            ),
          ),

          const SizedBox(height: 30),

          GestureDetector(
            onTap: _showGenderPicker,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Gender",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Row(
                  children: [
                    Text(
                      selectedGender,
                      style: const TextStyle(
                        color: Colors.blueAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Icon(Icons.arrow_drop_down, color: Colors.grey),
                  ],
                ),
              ],
            ),
          ),

          const Divider(height: 30),

          GestureDetector(
            onTap: _showDatePicker,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Date of Birth",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Row(
                  children: [
                    Text(
                      selectedDate,
                      style: const TextStyle(
                        color: Colors.blueAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Icon(Icons.arrow_drop_down, color: Colors.grey),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 80),

          SizedBox(
            width: double.infinity,
            height: 55,
            child: ElevatedButton(
              onPressed: _handleNextButton,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4C8CFF),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                "Next",
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  void _showGenderPicker() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Title
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                "Choose Gender",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),

            ListTile(
              title: const Text("Male"),
              onTap: () {
                setState(() {
                  selectedGender = "Male";
                });
                Navigator.pop(context);
              },
            ),

            ListTile(
              title: const Text("Female"),
              onTap: () {
                setState(() {
                  selectedGender = "Female";
                });
                Navigator.pop(context);
              },
            ),

            ListTile(
              title: const Text("Other"),
              onTap: () {
                setState(() {
                  selectedGender = "Other";
                });
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }

  void _showDatePicker() async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );

    if (pickedDate != null) {
      String formattedDate = DateFormat('dd/MMM/yyyy').format(pickedDate);
      setState(() {
        selectedDate = formattedDate;
      });
    }
  }

  void _handleNextButton() {
    // Get values
    String name = nameController.text;
    String gender = selectedGender;
    String dateOfBirth = selectedDate;

    if (name.isEmpty) {
      _showMessage("Please enter your name");
      return;
    }

    if (gender == "Select") {
      _showMessage("Please select your gender");
      return;
    }

    if (dateOfBirth == "Select") {
      _showMessage("Please select your date of birth");
      return;
    }

    _showSuccessMessage();

    print("Profile Complete!");

  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showSuccessMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Profile completed successfully!"),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }
}