import 'package:flutter/material.dart';
// Make sure this path matches your actual file location
import 'package:pillmate_college/screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // REMOVED 'const' from here because MySplashScreen is dynamic
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pill Reminder',
      home: const MySplashScreen(),
    );
  }
}